# Ab's Mod 文档入口

> 文档包修订：`2026-09-12.repository-progress.1`  
> 代码快照：`2e420203619b5d9cf0f1af7fbc5135ff8858f34f` · 核对日期：2026-09-12

## 先看结论

2026-09-12 复核：远端 main 相对 2026-09-10 包没有新增提交，compare 返回 identical。九阶物品、奶昔和客户端刀光仍按同一代码快照保留；长按/蓄力替换/连击/器灵仍待实现。本次没有新增玩法或修改数值，没有推送、访问本地工作树或运行游戏。

本轮更新进度核对日期、证据来源、任务交接模板与包级检查。故事、器灵、美术、完整连续战斗规格及平衡 JSON 保留上一版内容；专项文件的原修订日期不强行改为今天，以免制造内容变化。包级最新修订以 DOCUMENT_MANIFEST.json 为准。

## 阅读顺序

[STATUS](STATUS.md) → [CURRENT_TASK](CURRENT_TASK.md) → 对应专项。出现“已完成”争议时检查[REPOSITORY_AUDIT](REPOSITORY_AUDIT.md)和实际本地代码。

| 文件 | 用途 |
| --- | --- |
| [DEVELOPMENT.md](DEVELOPMENT.md) | 完整开发主规格、真实工程基线与不变ID |
| [LORE.md](LORE.md) | 故事设定、两路线、心魔与器灵关系 |
| [SPIRIT_SYSTEM.md](SPIRIT_SYSTEM.md) | 身份、好感、实体、转换、死亡与恢复 |
| [ART_GUIDE.md](ART_GUIDE.md) | 粉白/粉紫、细长轻灵、资产与动作规范 |
| [BALANCE.md](BALANCE.md) | 普通9阶/暗黑8阶与连击候选数值、技术依赖 |
| [BALANCE_PROFILE.json](BALANCE_PROFILE.json) | 机器可读设计表，不是已加载的运行时配置 |
| [CONTINUOUS_COMBAT.md](CONTINUOUS_COMBAT.md) | 长按、取消原版蓄力、服务端节奏和兼容主规格 |
| [COMBAT_INPUT.md](COMBAT_INPUT.md) | 旧名称跳转及INPUT/AUTO任务编号映射 |
| [STATUS.md](STATUS.md) / [CURRENT_TASK.md](CURRENT_TASK.md) | 源码事实、TODO和推荐下一批任务 |
| [REPOSITORY_AUDIT.md](REPOSITORY_AUDIT.md) / [JSON](REPOSITORY_AUDIT.json) | 固定commit证据、文件blob SHA、核对范围 |
| [DOCUMENT_CHANGELOG.md](DOCUMENT_CHANGELOG.md) | 本轮变更及来源合并说明 |
| [BALANCE_VALIDATION.json](BALANCE_VALIDATION.json) | 历史数值检查报告，未冒充新游戏实测 |
| [CONTINUOUS_COMBAT_VALIDATION.json](CONTINUOUS_COMBAT_VALIDATION.json) | 历史输入参考模拟报告，本轮未复跑 |
| [PACKAGE_VALIDATION.json](PACKAGE_VALIDATION.json) | 本轮文档/公式检查实际结果 |
| [DOCUMENT_MANIFEST.json](DOCUMENT_MANIFEST.json) | 包内文件相对路径、大小和SHA-256 |

## 真相与提案的优先级

最新明确用户决定控制“要做什么”；源码控制“已经做了什么”；测试结果控制“验证到哪一步”。不能让任一层代替另两层。
CONFIRMED是用户设定；PROPOSED/DRAFT是实现或文案建议；TBD需等决定；VERIFIED_SOURCE是源码证据而不是玩法批准。
本包保留前轮长文，不把简化索引替代完整规格。普通九阶22/5.0→35.2/6.0仍是候选，远端不是该数值。

## 安全导入

先阅读包根[APPLY_TO_REPO.md](../APPLY_TO_REPO.md)，按差异合并，不覆盖本地领先的STATUS或其他未提交内容。
[AGENTS_APPEND.md](../AGENTS_APPEND.md)是待合并片段，不是要替换现有AGENTS。本包不包含实际游戏源码、贴图、模型或JAR。
