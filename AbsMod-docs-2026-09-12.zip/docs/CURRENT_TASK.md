# 下一批开发任务单

> 修订：`2026-09-12.repository-progress.1` · 固定基线：`2e420203619b5d9cf0f1af7fbc5135ff8858f34f`  
> 任务状态：**READY_PROPOSED**，不是已启动/已完成的开发声明。

## 1. 本轮建议目标

先做普通喵刀“已在主手时按住攻击键连续出刀”的输入/节奏骨架；旧刀光继续复用。长按为用户明确目标，保留自定义动作间隔、具体网络协议和精确数值仍是提案。
2026-09-12 复核：远端仍为固定基线 2e42020，分支列表仅返回 main；当前没有远端新功能可以移入完成栏。本地未提交或未推送代码不可见，开工前必须核对工作树。若本地领先，应保留其实现并记录证据，不能照本表回退。

## 2. 必读与核对文件

依次读 `AGENTS.md`、`CONTRIBUTING.md`、本目录README、STATUS、CONTINUOUS_COMBAT、BALANCE和BALANCE_PROFILE。涉及长期身份时再读SPIRIT_SYSTEM。

现有入口：

```text
common/src/main/java/com/abyssredemption/absmod/item/MeowBladeStage.java
common/src/main/java/com/abyssredemption/absmod/item/MeowBladeItem.java
common/src/main/java/com/abyssredemption/absmod/command/ModCommands.java
common/src/main/java/com/abyssredemption/absmod/client/MeowSlashEffects.java
common/src/main/java/com/abyssredemption/absmod/client/SlashSwingTracker.java
26.2Fabric/src/main/java/com/abyssredemption/absmod/fabric/AbsModFabricClient.java
26.2NeoForge/src/main/java/com/abyssredemption/absmod/neoforge/AbsModNeoForgeClient.java
26.2Fabric/build.gradle
common/src/verification/java/com/abyssredemption/absmod/command/CommandVerification.java
```

实际用ModDevGradle，不重搭工程。候选22/5.0不是当前代码，当前仍7.0/-2.4。

## 3. 最小切片与检查点

### 切片A：BAL-01数据语义

设计表已存在。优先给阶段表加基础总攻速字段，并让武器/命令/说明读取同一来源。数值来自PROPOSED表，明确是测试平衡。保留ID和素材。
总伤害包含默认玩家基础值；总攻速不能直接当构造修正重复相加。`/absmod stages`若原来写死1.6须一起核对。
完成门槛：数值和tooltip/命令一致，两加载器编译；未跑游戏时保留实测TODO。

### 切片B：AUTO-01输入会话

客户端读取游戏“攻击/破坏”绑定，不硬编码鼠标编号。开始/更新/停止消息含会话与递增序号，不携带可信伤害/好感/层数。
服务端按玩家、世界、持物和可操作状态校验；界面/失焦无法直接由服务器读取，需要停止消息及超时兜底。
普通挖方块/物品使用/其他武器不被劫持。断线、换世界、切物品、死亡、旁观和输入过期终止会话。
完成门槛：能看到合法会话变化，重复/旧包不能重开或刷首刀。

### 切片C：AUTO-02唯一节奏器

按服务端游戏tick推进，保留小数余量。单击与长按同一动作预算，一tick最多一个主动作，停止和空挥不积攒多刀，低TPS不墙钟补刀。
五到六刀/秒是候选基准；稳定六刀不能无条件取整成每4tick一刀。读取含连击的属性后不要再乘一次同样加速。
每次授权建立唯一attackId；此阶段可仅调试输出，不同时执行原版攻击和自定义伤害。
完成门槛：单击、快点、松开重按不比同攻速长按更快；重复包不重复授权；数据异常安全拒绝。

## 4. 当前明确排除

不同时实现猫娘模型、好感最终阈值、进化配方、暗黑八阶、心魔、新的自动瞄准或范围伤害；不擅自改变刀光审美和资产。
AUTO-03/04没做时，不声称取消原版蓄力/高速有效命中已经完成。不得用全局无限攻速、清全局受伤时间或直接setHealth代替。
器灵处于实体形态时不能临时生成另一把剑出刀；自动召回触发仍TBD。第一批只处理已经合法装备的普通喵刀。

## 5. 后续接线

AUTO-03选择单一近战伤害入口，局部替换蓄力门槛/缩放，保留护甲/护盾/暴击条件/归属/取消事件。
AUTO-04验证目标受伤窗口、嵌套/反伤/多人/箭矢/燃烧。AUTO-05复用已有Geometry/Renderer，旧swing观察器与新attackId不能双播。
只有有效主命中才进入BAL-02叠层；六种视觉轨迹不是六段伤害。未命中可空挥但不刷Buff或共同战斗好感。

## 6. 测试与交付模板

根目录执行（属于建议执行命令，本包没有运行它们）：

```powershell
.\gradlew.bat :fabric:verifyCommands
.\gradlew.bat :fabric:build :neoforge:build
git diff --check
```

随后按CONTINUOUS_COMBAT游戏矩阵检查双端客户端/独立服务端和多人。离线调度模拟、Java检查、构建、游戏测试分开报告。

交付应写明：修改文件、实现的任务ID、仍然TODO、命令及真实结果、游戏是否启动、截图/日志位置；同步STATUS及两份README，不自动提交或推送。

## 7. 可直接给代码AI的指令

```text
以当前本地工作树为准，先读取AGENTS、CONTRIBUTING和docs/README.md。
根据docs/CURRENT_TASK.md开始最小切片：BAL-01必要前置，以及AUTO-01/AUTO-02输入/节奏骨架。
先列计划和既有实现，避免覆盖未提交改动。
保留原物品ID、奶昔、两加载器与六轨迹刀光。只操作本Mod状态，不做全局无冷却。
沿用明确标为PROPOSED的候选表，不发明未定重击、好感和Boss规则。
未接伤害/受伤窗口时明确标为调试骨架，不声称玩法完成。
按实际执行情况更新STATUS，分别记录自动检查、构建、游戏实测。
只完成最小切片，不自动提交或推送。
```

器灵并行入口仍是SPIRIT_SYSTEM第23节的身份与持久化任务，不因本单排队而被删掉或默认完成。


## 8. 本地执行后的交接记录模板 [PROPOSED]

此模板供实际编写代码的会话填写，本次没有填造结果。一次只推进一个可验收切片；不因用户说“继续”就把整个模块标为完成。

```text
记录时间：
当前分支 / HEAD：
工作树状态（是否存在未提交改动）：
任务 ID：BAL-01 / AUTO-01 / AUTO-02 / 其他已列任务
改动文件：
实现范围：
仍未接入的接口：
自动检查：命令、结果、日志位置；未运行则写 NOT_RUN
两加载器构建：命令、结果、日志位置；未运行则写 NOT_RUN
游戏验收：加载器、单机/服务器、场景、结果；未运行则写 NOT_TESTED
更新的 TODO 项及对应证据：
下一步最小任务：
是否提交 / 推送：只记录实际结果
```

验收进阶规则：
- BAL-01 的纯数据/编译结果不能证明真实攻击频率已变化。
- AUTO-01/02 的会话与节奏日志不能证明伤害已接通。
- AUTO-03/04 的实现存在但未验证时，继续保留冷却兼容与多人测试项。
- 现有六轨迹刀光不能充当上述任何服务端验收的证据。
- 不覆盖本地已有的实际测试结果；冲突时合并记录并注明不同 commit/环境。
